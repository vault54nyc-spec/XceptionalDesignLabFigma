import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import ScrollToTop from "./components/ScrollToTop"; // ✅ ADDED: Import ScrollToTop
import Home from "./pages/Home";
import Operations from "./pages/Operations";
import Technical from "./pages/Technical";
import Communications from "./pages/Communications";
import Design from "./pages/Design";
import Packages from "./pages/Packages";
import About from "./pages/About";
import CaseStudies from "./pages/CaseStudies";
import Contact from "./pages/Contact";
import Services from "./pages/Services";

function Router() {
  return (
    <>
      {/* ✅ ADDED: ScrollToTop component to fix navigation scroll positioning */}
      <ScrollToTop />
      <Switch>
        <Route path={"/"} component={Home} />
        <Route path={"/operations"} component={Operations} />
        <Route path={"/technical"} component={Technical} />
        <Route path={"/communications"} component={Communications} />
        <Route path={"/design"} component={Design} />
        <Route path={"/packages"} component={Packages} />
        <Route path={"/services"} component={Services} />
        <Route path={"/about"} component={About} />
        <Route path={"/case-studies"} component={CaseStudies} />
        <Route path={"/contact"} component={Contact} />
        <Route path={"/404"} component={NotFound} />
        {/* Final fallback route */}
        <Route component={NotFound} />
      </Switch>
    </>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
